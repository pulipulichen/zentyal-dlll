phpSQLiteAdmin is being developed under the GNU GPL license.
See the file copying.txt for license details.

How to use:
phpSQLiteAdmin makes use of a simple user system. The default information is listed below:
Default username: root
Default password: root

phpSQLiteAdmin makes use of the "Simple Power SQLite class",
see http://www.php-power.it/SPSQLiteClass.php
Some additions and modifications to this class have been made to fit our needs.
SPSQLite.class-0.6.php:		Original file
SPSQLite.class.php:		File which has been modified by us.
SPSQLite.class.diff		diff -u between both


The official project website is http://phpsqliteadmin.sourceforge.net
Check it out for more information.


There is another project around that uses the same name. It had it's first
appearance in february 2004 while we made our first release in august 2003. Bastard.
