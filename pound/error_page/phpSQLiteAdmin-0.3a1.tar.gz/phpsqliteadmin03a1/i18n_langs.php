<?php

$strings = array(

// Application html-title
1 => 'phpSQLiteAdmin 0.3',

// dbconfig.php
2 => 'Add a new database alias',
3 => 'Available databases:',
4 => 'Alias',
5 => 'Database file',
6 => 'Description',

);

?>