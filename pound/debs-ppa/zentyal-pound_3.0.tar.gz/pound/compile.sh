cd ~/pound
zentyal-package
sudo dpkg -i debs-ppa/zentyal-pound_3.0_all.deb
