/etc/init.d/pound stop
/etc/init.d/pound start
