cd ~/pound
perl -c src/EBox/*.pm
perl -c src/EBox/*/Model/*.pm
perl -c src/EBox/*/Composite/*.pm