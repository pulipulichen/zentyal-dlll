cd ~/pound
perl -c src/EBox/*.pm
perl -c src/EBox/*/Model/*.pm