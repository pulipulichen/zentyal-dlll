cd ~/apache2
zentyal-package
sudo dpkg -i debs-ppa/zentyal-apache2_3.0_all.deb
