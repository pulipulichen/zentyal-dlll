umount /opt/mfschunkservers/*
